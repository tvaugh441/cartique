
const cars = [
  {
    name: "1965 Ford Mustang",
    make: "Ford",
    year: 1965,
    price: 35000,
    image: "https://source.unsplash.com/400x300/?mustang,classic"
  },
  {
    name: "1957 Chevrolet Bel Air",
    make: "Chevrolet",
    year: 1957,
    price: 48000,
    image: "https://source.unsplash.com/400x300/?belair,vintage"
  },
  {
    name: "1963 Jaguar E-Type",
    make: "Jaguar",
    year: 1963,
    price: 120000,
    image: "https://source.unsplash.com/400x300/?jaguar,classics"
  },
  {
    name: "1969 Dodge Charger",
    make: "Dodge",
    year: 1969,
    price: 55000,
    image: "https://source.unsplash.com/400x300/?charger,classiccar"
  },
  {
    name: "1955 Mercedes-Benz 300SL",
    make: "Mercedes-Benz",
    year: 1955,
    price: 1400000,
    image: "https://source.unsplash.com/400x300/?mercedes,vintagecar"
  },
  {
    name: "1970 Pontiac GTO",
    make: "Pontiac",
    year: 1970,
    price: 60000,
    image: "https://source.unsplash.com/400x300/?gto,classic"
  }
];

const gallery = document.getElementById("carGallery");
const makeFilter = document.getElementById("makeFilter");
const yearFilter = document.getElementById("yearFilter");
const priceFilter = document.getElementById("priceFilter");

function populateFilters() {
  const makes = [...new Set(cars.map(car => car.make))];
  const years = [...new Set(cars.map(car => car.year))];
  makes.forEach(make => makeFilter.innerHTML += `<option value="${make}">${make}</option>`);
  years.sort().forEach(year => yearFilter.innerHTML += `<option value="${year}">${year}</option>`);
  priceFilter.innerHTML += "<option value='0-50000'>Under $50,000</option>";
  priceFilter.innerHTML += "<option value='50000-100000'>$50,000 - $100,000</option>";
  priceFilter.innerHTML += "<option value='100000-9999999'>Over $100,000</option>";
}

function displayCars(list) {
  gallery.innerHTML = "";
  list.forEach(car => {
    gallery.innerHTML += `
      <div class="car-card">
        <img src="${car.image}" alt="${car.name}" />
        <div class="car-info">
          <h3>${car.name}</h3>
          <p>Year: ${car.year}</p>
          <p>Price: $${car.price.toLocaleString()}</p>
        </div>
      </div>`;
  });
}

function applyFilters() {
  const make = makeFilter.value;
  const year = parseInt(yearFilter.value);
  const [min, max] = priceFilter.value.split("-").map(Number);
  let filtered = cars;
  if (make) filtered = filtered.filter(car => car.make === make);
  if (year) filtered = filtered.filter(car => car.year === year);
  if (priceFilter.value) filtered = filtered.filter(car => car.price >= min && car.price <= max);
  displayCars(filtered);
}

makeFilter.addEventListener("change", applyFilters);
yearFilter.addEventListener("change", applyFilters);
priceFilter.addEventListener("change", applyFilters);

populateFilters();
displayCars(cars);
